import {Component, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {ActivatedRoute, Router} from '@angular/router';
import {UserService} from 'src/app/user-service.service';
import {User} from 'src/app/user';

import {MustMatch} from 'src/app/register/MustMatch';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  registerForm: FormGroup;
  submitted = false;
  loading = false;
  user: User;

  constructor(private formBuilder: FormBuilder, private router: Router,
              private userService: UserService,
              private route: ActivatedRoute) {
    this.user = new User();
  }

  ngOnInit(): void {
    this.registerForm = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirmPassword: ['', [Validators.required]]
    }, {
      validator: MustMatch('password', 'confirmPassword')
    });
  }

  // tslint:disable-next-line:typedef
  get f() {
    return this.registerForm.controls;
  }


  // tslint:disable-next-line:typedef
  onSubmit() {
    this.submitted = true;
    if (this.registerForm.invalid) {
      return;
    }

    this.loading = true;

    this.userService.save(this.user).subscribe(result => {
      this.gotoLoginPage();
    }, error => {
      this.loading = false;
      alert('Some of the fields are not correct or you already registered');
    });
  }

  // tslint:disable-next-line:typedef
  gotoLoginPage() {
    this.router.navigate(['/login']);
  }
}
