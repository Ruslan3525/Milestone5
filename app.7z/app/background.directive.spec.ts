import { BackgroundDirective } from './background.directive';

describe('BackgroundDirective', () => {
  it('should create an instance', () => {
    const directive = new BackgroundDirective();
    expect(directive).toBeTruthy();
  });
});
