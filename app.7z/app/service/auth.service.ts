import {Injectable} from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  loggedIn = false;

  constructor() {
  }

  // tslint:disable-next-line:typedef
  logout() {
    this.loggedIn = false;
  }
}
